public class yearUpProfile {
    public static void main(String[] args) {
        System.out.println("************************Year Up Profile************************"); 
        System.out.println("Name: Jonas Brobeck"); 
        System.out.println("Campus: Pittsburgh"); 
        System.out.println("Career Goal: Sysadmin"); 
        System.out.println("Age: 22"); 
        System.out.println("Brief Intro:"); 
        System.out.println("I enjoy playing games and working with computers."); 

    }
}
